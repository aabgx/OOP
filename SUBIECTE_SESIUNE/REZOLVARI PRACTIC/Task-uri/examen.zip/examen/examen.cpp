#include "examen.h"

examen::examen(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
